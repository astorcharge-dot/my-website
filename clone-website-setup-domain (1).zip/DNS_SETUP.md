# 🌐 DNS Setup - Where to Put the DNS Codes

## Quick Answer:
**You need to add DNS records at your DOMAIN REGISTRAR** (where you bought hangbei.co)

---

## 📍 Finding Your DNS Settings

### Step 1: Identify Where You Bought Your Domain

Your domain registrar is the company where you purchased `hangbei.co`. Common registrars:
- GoDaddy
- Namecheap
- Google Domains
- Cloudflare
- Hover
- Domain.com
- Bluehost
- HostGator

### Step 2: Log In to Your Registrar

Go to the website where you bought your domain and log in.

### Step 3: Find DNS Management

Look for one of these terms:
- DNS Management
- DNS Settings
- Manage DNS
- Advanced DNS
- DNS Records
- Domain Settings → DNS

---

## 📋 DNS Records to Add

### For GitHub Pages Deployment:

Copy and paste these exact values into your DNS settings:

```
╔════════════════════════════════════════════════╗
║            DNS RECORDS TO ADD                   ║
╚════════════════════════════════════════════════╝

Record #1
─────────────────────────────
Type:     A
Name:     @ (or blank or apex)
Value:    185.199.108.153
TTL:      3600

Record #2
─────────────────────────────
Type:     A
Name:     @ (or blank or apex)
Value:    185.199.109.153
TTL:      3600

Record #3
─────────────────────────────
Type:     A
Name:     @ (or blank or apex)
Value:    185.199.110.153
TTL:      3600

Record #4
─────────────────────────────
Type:     A
Name:     @ (or blank or apex)
Value:    185.199.111.153
TTL:      3600

Record #5 (for www subdomain)
─────────────────────────────
Type:     CNAME
Name:     www
Value:    YOUR_GITHUB_USERNAME.github.io
TTL:      3600
```

**Remember:** Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username!

---

## 🎯 Visual Guide for Common Registrars

### GoDaddy
```
1. Login to GoDaddy.com
2. Click "My Products"
3. Find your domain → Click "DNS"
4. Scroll to "Records" section
5. Click "Add" button
6. Enter the DNS records above
```

### Namecheap
```
1. Login to Namecheap.com
2. Go to "Domain List"
3. Click "Manage" next to hangbei.co
4. Click "Advanced DNS" tab
5. Click "Add New Record"
6. Enter the DNS records above
```

### Google Domains
```
1. Login to domains.google.com
2. Click on hangbei.co
3. Click "DNS" in the left menu
4. Scroll to "Custom resource records"
5. Add the DNS records above
```

### Cloudflare
```
1. Login to Cloudflare.com
2. Select hangbei.co domain
3. Click "DNS" icon
4. Click "Add record"
5. Enter the DNS records above
6. Set Proxy status to "DNS only" (gray cloud)
```

---

## ⚠️ Important Notes

### About the "Name" Field:
Different registrars use different terms:
- **@** = root domain (hangbei.co)
- **blank** = same as @
- **apex** = same as @

All three mean the same thing - they point to your main domain.

### About TTL:
- TTL = "Time to Live"
- 3600 = 1 hour (recommended)
- Some registrars use "Auto" - that's fine too

### Delete Old Records:
If you have existing A records or CNAME records, you may need to delete them first to avoid conflicts.

---

## ✅ Verification

After adding DNS records, verify they're correct:

1. **Wait 15-30 minutes** for DNS to start propagating

2. **Check DNS propagation:**
   - Visit: https://www.whatsmydns.net/
   - Enter: hangbei.co
   - Type: A
   - Click Search
   - Should show GitHub's IP addresses

3. **Test your domain:**
   ```bash
   # On Mac/Linux, open Terminal and run:
   nslookup hangbei.co
   
   # Should show:
   # 185.199.108.153
   # 185.199.109.153
   # 185.199.110.153
   # 185.199.111.153
   ```

---

## 🔄 DNS Propagation Timeline

```
Immediately       → DNS records saved at registrar
15-30 minutes     → Usually starts working
1-2 hours         → Should be fully working
Up to 48 hours    → Maximum time (rare)
```

**Pro tip:** Use incognito/private browsing to test without cache issues.

---

## 🆘 Troubleshooting

### "I can't find DNS settings"
- Contact your domain registrar's support
- Search: "[your registrar name] how to edit DNS records"
- Most registrars have live chat or phone support

### "DNS not propagating"
- Wait longer (can take up to 48 hours)
- Clear your browser cache
- Try accessing from a different device/network
- Use mobile data instead of WiFi

### "Getting SSL/HTTPS errors"
- Wait for DNS to fully propagate first
- Then enable "Enforce HTTPS" in GitHub Pages settings
- SSL certificate can take 24 hours to provision

### "Site shows 404 error"
- Verify CNAME file exists in public folder
- Check GitHub Pages settings show your domain
- Redeploy: `npm run deploy`

---

## 📞 Where to Get Help

1. **Your Domain Registrar's Support:**
   - They can help with DNS settings
   - Usually have 24/7 chat support

2. **GitHub Docs:**
   - https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

3. **Check if DNS is working:**
   - https://www.whatsmydns.net/
   - https://dnschecker.org/

---

## 📝 Example: Complete Setup

Let's say your GitHub username is "johndoe"

**DNS Records:**
```
A      @      185.199.108.153
A      @      185.199.109.153  
A      @      185.199.110.153
A      @      185.199.111.153
CNAME  www    johndoe.github.io
```

**In GitHub:**
- Repository: johndoe/hangbei-website
- Custom domain: hangbei.co
- CNAME file contains: hangbei.co

**Result:**
- http://hangbei.co → redirects to https://hangbei.co ✅
- http://www.hangbei.co → redirects to https://hangbei.co ✅
- https://hangbei.co → your website ✅
- https://www.hangbei.co → your website ✅

---

**You've got this! 🚀**
