export function Hero() {
  return (
    <section id="home" className="relative pt-20 pb-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-emerald-50 to-teal-50 -z-10"></div>
      
      <div className="max-w-7xl mx-auto mt-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center px-4 py-2 bg-emerald-100 rounded-full text-emerald-700 font-medium text-sm">
              <span className="w-2 h-2 bg-emerald-600 rounded-full mr-2 animate-pulse"></span>
              Trusted Business Partner Since 2020
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight">
              Strategic Solutions
              <span className="block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mt-2">
                For Your Business Growth
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 leading-relaxed max-w-2xl">
              At DIVINE APEX LLC, we transform challenges into opportunities. Our expert team delivers innovative strategies and solutions that drive real results for your business.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a
                href="#contact"
                className="group relative px-8 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1"
              >
                <span className="relative z-10">Start Your Journey</span>
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-700 to-teal-700 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </a>
              <a
                href="#services"
                className="px-8 py-4 border-2 border-emerald-600 text-emerald-700 rounded-xl font-semibold hover:bg-emerald-50 transition-all duration-300"
              >
                Explore Services
              </a>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-emerald-600">250+</div>
                <div className="text-sm text-gray-600 mt-1">Clients Served</div>
              </div>
              <div className="text-center border-x border-gray-200">
                <div className="text-3xl font-bold text-emerald-600">98%</div>
                <div className="text-sm text-gray-600 mt-1">Success Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-emerald-600">15+</div>
                <div className="text-sm text-gray-600 mt-1">Years Experience</div>
              </div>
            </div>
          </div>

          {/* Right Content - Visual Element */}
          <div className="relative lg:h-[600px]">
            {/* Floating Cards */}
            <div className="relative h-full flex items-center justify-center">
              {/* Card 1 */}
              <div className="absolute top-0 right-0 w-64 bg-white rounded-2xl shadow-2xl p-6 transform hover:scale-105 transition-transform duration-300">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <span className="text-green-500 text-sm font-semibold">+32%</span>
                </div>
                <h3 className="font-bold text-gray-900 mb-1">Revenue Growth</h3>
                <p className="text-gray-500 text-sm">Average client increase</p>
                <div className="mt-4 h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full w-3/4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"></div>
                </div>
              </div>

              {/* Card 2 */}
              <div className="absolute bottom-20 left-0 w-72 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-2xl shadow-2xl p-6 text-white transform hover:scale-105 transition-transform duration-300">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                    <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-sm opacity-90">Performance</div>
                    <div className="text-2xl font-bold">Excellent</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="opacity-90">Strategy</span>
                    <span>95%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="opacity-90">Execution</span>
                    <span>98%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="opacity-90">Results</span>
                    <span>100%</span>
                  </div>
                </div>
              </div>

              {/* Card 3 */}
              <div className="absolute top-1/2 -right-4 w-56 bg-white rounded-2xl shadow-xl p-5 transform -translate-y-1/2 hover:scale-105 transition-transform duration-300">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-teal-400 rounded-full"></div>
                  <div>
                    <div className="font-semibold text-gray-900 text-sm">Client Success</div>
                    <div className="text-xs text-gray-500">Latest achievement</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="flex -space-x-2">
                    <div className="w-8 h-8 bg-emerald-200 rounded-full border-2 border-white"></div>
                    <div className="w-8 h-8 bg-teal-200 rounded-full border-2 border-white"></div>
                    <div className="w-8 h-8 bg-blue-200 rounded-full border-2 border-white"></div>
                  </div>
                  <span className="text-xs text-gray-600">+180 happy clients</span>
                </div>
              </div>

              {/* Background decorative elements */}
              <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-emerald-200 rounded-full filter blur-3xl opacity-30"></div>
              <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-teal-200 rounded-full filter blur-3xl opacity-30"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
