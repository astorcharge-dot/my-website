export function About() {
  return (
    <section id="about" className="py-24 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="order-2 lg:order-1">
            <div className="inline-block mb-6">
              <span className="px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-semibold">
                About Us
              </span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-6">
              Empowering Businesses to Reach Their
              <span className="block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mt-2">
                Divine Apex
              </span>
            </h2>
            
            <div className="space-y-4 text-lg text-gray-600 leading-relaxed">
              <p>
                Based in Sheridan, Wyoming, <span className="font-semibold text-gray-900">DIVINE APEX LLC</span> is your trusted partner for business transformation and growth. We combine strategic insight with practical execution to help businesses overcome challenges and seize opportunities.
              </p>
              <p>
                Our team of experienced consultants brings decades of combined expertise across multiple industries. We believe in building lasting partnerships with our clients, understanding their unique challenges, and delivering solutions that create measurable impact.
              </p>
              <p>
                Whether you're a startup finding your footing or an established enterprise seeking transformation, we provide the strategic guidance and hands-on support you need to succeed in today's competitive landscape.
              </p>
            </div>
            
            {/* Core Values */}
            <div className="mt-10 grid grid-cols-2 gap-6">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">Excellence</h4>
                  <p className="text-sm text-gray-600">Uncompromising quality</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">Innovation</h4>
                  <p className="text-sm text-gray-600">Forward-thinking solutions</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">Integrity</h4>
                  <p className="text-sm text-gray-600">Honest partnerships</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">Results</h4>
                  <p className="text-sm text-gray-600">Measurable outcomes</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Content - Stats & Visual */}
          <div className="order-1 lg:order-2 relative">
            <div className="bg-gradient-to-br from-emerald-600 to-teal-600 rounded-3xl p-1">
              <div className="bg-white rounded-3xl p-10">
                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-8 mb-10">
                  <div className="text-center">
                    <div className="text-5xl font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-2">
                      250+
                    </div>
                    <div className="text-gray-600 font-medium">Projects Completed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-5xl font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-2">
                      98%
                    </div>
                    <div className="text-gray-600 font-medium">Client Satisfaction</div>
                  </div>
                  <div className="text-center">
                    <div className="text-5xl font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-2">
                      15+
                    </div>
                    <div className="text-gray-600 font-medium">Years Experience</div>
                  </div>
                  <div className="text-center">
                    <div className="text-5xl font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-2">
                      24/7
                    </div>
                    <div className="text-gray-600 font-medium">Support Available</div>
                  </div>
                </div>

                {/* Mission Statement */}
                <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-2">Our Mission</h4>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        To empower businesses with strategic solutions that drive sustainable growth and create lasting value for all stakeholders.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Decorative elements */}
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-emerald-200 rounded-full filter blur-2xl opacity-50 -z-10"></div>
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-teal-200 rounded-full filter blur-2xl opacity-50 -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
