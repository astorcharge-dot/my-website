export function Solutions() {
  const solutions = [
    {
      name: 'Startup Package',
      description: 'Perfect for new businesses ready to make their mark',
      price: 'Custom',
      period: 'pricing',
      features: [
        'Business plan development',
        'Market analysis & research',
        'Brand strategy consultation',
        'Initial setup guidance',
        'Monthly progress reviews'
      ],
      highlighted: false,
      color: 'blue'
    },
    {
      name: 'Growth Accelerator',
      description: 'Ideal for established businesses seeking expansion',
      price: 'Tailored',
      period: 'solutions',
      features: [
        'Comprehensive growth strategy',
        'Process optimization',
        'Advanced market analysis',
        'Team development workshops',
        'Bi-weekly strategy sessions',
        'Performance tracking',
        'Priority support access'
      ],
      highlighted: true,
      color: 'emerald'
    },
    {
      name: 'Enterprise Elite',
      description: 'Full-scale transformation for industry leaders',
      price: 'Premium',
      period: 'partnership',
      features: [
        'Complete business transformation',
        'Executive coaching program',
        'Custom technology integration',
        'Dedicated account manager',
        '24/7 strategic support',
        'Quarterly board presentations',
        'Global market expansion',
        'Unlimited consultations'
      ],
      highlighted: false,
      color: 'purple'
    }
  ];

  return (
    <section id="solutions" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 via-emerald-50/30 to-teal-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-20">
          <div className="inline-block mb-4">
            <span className="px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-semibold">
              Pricing Plans
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-6">
            Solutions That Scale With You
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose the perfect package for your business journey. All solutions include our commitment to your success.
          </p>
        </div>

        {/* Solutions Grid */}
        <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {solutions.map((solution, index) => (
            <div
              key={index}
              className={`relative rounded-3xl p-8 transition-all duration-300 ${
                solution.highlighted
                  ? 'bg-gradient-to-br from-emerald-600 to-teal-600 text-white shadow-2xl scale-105 lg:scale-110'
                  : 'bg-white text-gray-900 shadow-lg hover:shadow-2xl'
              }`}
            >
              {solution.highlighted && (
                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2">
                  <span className="inline-flex items-center px-4 py-2 bg-yellow-400 text-gray-900 rounded-full text-sm font-bold shadow-lg">
                    <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    Recommended
                  </span>
                </div>
              )}
              
              <div className="text-center mb-8 mt-4">
                <h3 className={`text-2xl font-bold mb-2 ${solution.highlighted ? 'text-white' : 'text-gray-900'}`}>
                  {solution.name}
                </h3>
                <p className={`text-sm mb-6 ${solution.highlighted ? 'text-emerald-100' : 'text-gray-500'}`}>
                  {solution.description}
                </p>
                <div className="mb-2">
                  <span className={`text-4xl font-extrabold ${solution.highlighted ? 'text-white' : 'text-emerald-600'}`}>
                    {solution.price}
                  </span>
                </div>
                <span className={`text-sm ${solution.highlighted ? 'text-emerald-100' : 'text-gray-500'}`}>
                  {solution.period}
                </span>
              </div>

              <ul className="space-y-4 mb-8">
                {solution.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start">
                    <svg
                      className={`w-6 h-6 mr-3 flex-shrink-0 ${
                        solution.highlighted ? 'text-emerald-200' : 'text-emerald-500'
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className={`text-sm ${solution.highlighted ? 'text-white' : 'text-gray-600'}`}>
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              <a
                href="#contact"
                className={`block w-full py-4 px-6 rounded-xl font-bold text-center transition-all duration-300 ${
                  solution.highlighted
                    ? 'bg-white text-emerald-600 hover:bg-emerald-50 shadow-lg'
                    : 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white hover:from-emerald-700 hover:to-teal-700 shadow-md hover:shadow-lg'
                }`}
              >
                Get Started
              </a>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <p className="text-gray-600 mb-4">
            Need a custom solution? We're here to help.
          </p>
          <a
            href="#contact"
            className="inline-flex items-center text-emerald-600 font-semibold hover:text-emerald-700 transition-colors"
          >
            Contact us for a personalized quote
            <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}
