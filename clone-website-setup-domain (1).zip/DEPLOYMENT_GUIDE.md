# 🚀 Quick Deployment Guide

## Step-by-Step Instructions to Deploy Your Hangbei Website

### Step 1: Upload Code to GitHub

1. **Create a new repository on GitHub:**
   - Go to https://github.com/new
   - Repository name: `hangbei-website` (or any name you prefer)
   - Make it Public
   - Click "Create repository"

2. **Upload your code:**

Open terminal in your project folder and run:

```bash
git init
git add .
git commit -m "Initial commit - Hangbei website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/hangbei-website.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

### Step 2: Deploy to GitHub Pages

**Option A: Automatic Deployment (Recommended)**

1. Install gh-pages package:
```bash
npm install --save-dev gh-pages
```

2. Edit your `package.json` file:

Add this line at the top level (after "name" or "version"):
```json
"homepage": "https://YOUR_USERNAME.github.io/hangbei-website",
```

Add these to the "scripts" section:
```json
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"
```

3. Deploy:
```bash
npm run deploy
```

4. Enable GitHub Pages:
   - Go to your repository on GitHub
   - Click "Settings" tab
   - Click "Pages" in the left sidebar
   - Under "Source", select `gh-pages` branch
   - Click "Save"

**Your site will be live at:** `https://YOUR_USERNAME.github.io/hangbei-website`

### Step 3: Connect Your Custom Domain (hangbei.co)

#### A. In Your GitHub Repository:

1. Create a file named `CNAME` in the `public` folder
2. Add just one line with your domain: `hangbei.co`
3. Commit and push:
```bash
git add public/CNAME
git commit -m "Add custom domain"
git push
npm run deploy
```

4. Go to GitHub repository Settings → Pages
5. Enter `hangbei.co` in the Custom domain field
6. Click Save

#### B. Configure DNS at Your Domain Registrar:

**🔑 THIS IS WHERE YOU PUT THE DNS CODES:**

Go to where you bought your domain (hangbei.co). This could be:
- GoDaddy
- Namecheap  
- Google Domains
- Cloudflare
- Hover
- etc.

Find the DNS settings page (usually called "DNS Management" or "DNS Settings")

**Add these records:**

**Record 1:**
```
Type: A
Host/Name: @ (or leave blank)
Value/Points to: 185.199.108.153
TTL: 3600 (or Auto)
```

**Record 2:**
```
Type: A
Host/Name: @ (or leave blank)
Value/Points to: 185.199.109.153
TTL: 3600 (or Auto)
```

**Record 3:**
```
Type: A
Host/Name: @ (or leave blank)
Value/Points to: 185.199.110.153
TTL: 3600 (or Auto)
```

**Record 4:**
```
Type: A
Host/Name: @ (or leave blank)
Value/Points to: 185.199.111.153
TTL: 3600 (or Auto)
```

**Record 5 (for www):**
```
Type: CNAME
Host/Name: www
Value/Points to: YOUR_USERNAME.github.io
TTL: 3600 (or Auto)
```

**Important Notes:**
- Replace `YOUR_USERNAME` with your actual GitHub username
- Some registrars use "@" for the root domain, others leave it blank
- TTL of 3600 is recommended (1 hour)

### Step 4: Wait for DNS Propagation

- Usually takes 15 minutes to 2 hours
- Can take up to 48 hours in rare cases
- Check status at: https://www.whatsmydns.net/

### Step 5: Enable HTTPS

After DNS propagates (wait 30-60 minutes):

1. Go to GitHub repository Settings → Pages
2. Check the box "Enforce HTTPS"
3. Wait a few minutes for SSL certificate to provision

**Done! Your website should now be live at https://hangbei.co** 🎉

---

## 🔍 Troubleshooting

### Site not loading after deployment:
- Wait 5-10 minutes after running `npm run deploy`
- Clear your browser cache
- Check if gh-pages branch exists in your repository

### Custom domain not working:
- Verify CNAME file exists in public folder
- Check DNS records are correct
- Wait for DNS propagation (up to 48 hours)
- Use https://www.whatsmydns.net/ to check DNS status

### "Page not found" error:
- Make sure gh-pages branch is selected in Settings → Pages
- Verify homepage URL in package.json matches your repository name
- Try redeploying: `npm run deploy`

### Need to update the site:
```bash
# Make your changes
git add .
git commit -m "Update website"
git push
npm run deploy
```

---

## 📱 Common DNS Provider Locations

**GoDaddy:**
1. Login → My Products
2. Click on your domain
3. Find "DNS" or "Manage DNS"
4. Add records in the "Records" section

**Namecheap:**
1. Dashboard → Domain List
2. Click "Manage" next to your domain
3. Go to "Advanced DNS" tab
4. Add records under "Host Records"

**Google Domains:**
1. My Domains
2. Click DNS
3. Scroll to "Custom resource records"
4. Add your records

**Cloudflare:**
1. Select your domain
2. Click DNS icon
3. Add records

**Hover:**
1. Click on your domain
2. Select DNS tab
3. Add records

---

## ✅ Checklist

- [ ] Code pushed to GitHub
- [ ] gh-pages package installed
- [ ] package.json updated with homepage and deploy scripts
- [ ] Ran `npm run deploy`
- [ ] gh-pages branch selected in GitHub Settings
- [ ] CNAME file created in public folder
- [ ] DNS A records added to domain registrar
- [ ] DNS CNAME record added for www
- [ ] Custom domain entered in GitHub Pages settings
- [ ] Waited for DNS propagation
- [ ] HTTPS enabled

---

## 🆘 Need Help?

If you're stuck, create an issue on GitHub or check:
- GitHub Pages documentation: https://pages.github.com/
- Your domain registrar's DNS documentation
- DNS checker: https://www.whatsmydns.net/
