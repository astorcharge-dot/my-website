# DIVINE APEX LLC - Professional Business Website

A modern, responsive business website built with React, TypeScript, Vite, and Tailwind CSS.

## 🚀 Features

- **Responsive Design** - Works perfectly on desktop, tablet, and mobile devices
- **Modern UI/UX** - Clean, professional design with smooth animations
- **Fast Performance** - Built with Vite for lightning-fast load times
- **SEO Friendly** - Optimized for search engines
- **Contact Form** - Easy-to-use contact form for client inquiries
- **Service Showcase** - Highlights your business services and solutions
- **Professional Branding** - Custom color scheme with emerald/teal gradient theme

## 📋 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn
- Git

### Installation

1. Clone this repository:
```bash
git clone <your-repo-url>
cd divine-apex-website
```

2. Install dependencies:
```bash
npm install
```

3. Run development server:
```bash
npm run dev
```

4. Build for production:
```bash
npm run build
```

## 🌐 Deployment to GitHub Pages

### Step 1: Create GitHub Repository

1. Go to [GitHub](https://github.com) and create a new repository
2. Name it something like `divine-apex-website`
3. Make it **Public**
4. Click "Create repository"

### Step 2: Push Code to GitHub

```bash
git init
git add .
git commit -m "Initial commit - DIVINE APEX website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/divine-apex-website.git
git push -u origin main
```

**Replace `YOUR_USERNAME` with your actual GitHub username!**

### Step 3: Install Deployment Package

```bash
npm install --save-dev gh-pages
```

### Step 4: Update package.json

Add these lines to your `package.json`:

**Add after "name" or "version":**
```json
"homepage": "https://YOUR_USERNAME.github.io/divine-apex-website",
```

**Add to "scripts" section:**
```json
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"
```

### Step 5: Deploy

```bash
npm run deploy
```

Wait 30-60 seconds for deployment to complete.

### Step 6: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** → **Pages**
3. Under "Source", select **gh-pages** branch
4. Click **Save**

Your site will be live at: `https://YOUR_USERNAME.github.io/divine-apex-website`

## 🔧 Custom Domain Setup (DNS Configuration)

### Your Domain Information
If you have a custom domain (e.g., `divineapex.com`), follow these steps:

### A. Configure DNS Records

**Go to your domain registrar** (GoDaddy, Namecheap, Cloudflare, etc.) and add these DNS records:

#### For GitHub Pages:

```
Type: A      Name: @      Value: 185.199.108.153      TTL: 3600
Type: A      Name: @      Value: 185.199.109.153      TTL: 3600
Type: A      Name: @      Value: 185.199.110.153      TTL: 3600
Type: A      Name: @      Value: 185.199.111.153      TTL: 3600
Type: CNAME  Name: www    Value: YOUR_USERNAME.github.io  TTL: 3600
```

**Replace `YOUR_USERNAME` with your GitHub username!**

### B. Update CNAME File

The `public/CNAME` file should contain your domain:
```
divineapex.com
```

(Already configured in this project - just update with your actual domain)

### C. Configure GitHub Pages

1. Go to GitHub repository → **Settings** → **Pages**
2. Under "Custom domain", enter: `divineapex.com`
3. Click **Save**
4. Wait for DNS propagation (15 min - 48 hours)
5. Check ✅ **Enforce HTTPS** (after DNS propagates)

## 📍 Where to Add DNS Records

### Common Registrars:

**GoDaddy:**
- Login → My Products → Domains → DNS

**Namecheap:**
- Domain List → Manage → Advanced DNS

**Google Domains:**
- My Domains → DNS → Custom resource records

**Cloudflare:**
- Select domain → DNS → Add record

## 🔄 Updating Your Site

After making changes:

```bash
git add .
git commit -m "Updated content"
git push
npm run deploy
```

Changes will be live in 1-2 minutes.

## 📱 Contact Information

Current contact details in the website:

- **Company:** DIVINE APEX LLC
- **Address:** 30 N Gould St Ste R, Sheridan, WY 82801
- **Phone:** (717) 478-3674
- **Email:** tylermissinger@gmail.com

To update this information, edit the following files:
- `src/components/Contact.tsx` - Contact section
- `src/components/Footer.tsx` - Footer

## 🎨 Customization

### Change Colors

The website uses an emerald/teal color scheme. To change:

1. Search for `emerald-` and `teal-` in component files
2. Replace with your preferred Tailwind colors (e.g., `blue-`, `purple-`, `red-`)

### Update Content

- **Services:** Edit `src/components/Services.tsx`
- **Solutions/Pricing:** Edit `src/components/Solutions.tsx`
- **About Section:** Edit `src/components/About.tsx`
- **Hero Section:** Edit `src/components/Hero.tsx`

### Change Logo

Update the logo in:
- `src/components/Header.tsx` (line 13-18)
- `src/components/Footer.tsx` (line 11-16)

## 📂 Project Structure

```
divine-apex-website/
├── public/
│   └── CNAME                    # Custom domain
├── src/
│   ├── components/
│   │   ├── Header.tsx          # Navigation
│   │   ├── Hero.tsx            # Landing section
│   │   ├── Services.tsx        # Services showcase
│   │   ├── Solutions.tsx       # Pricing/Solutions
│   │   ├── About.tsx           # About section
│   │   ├── Contact.tsx         # Contact form
│   │   └── Footer.tsx          # Footer
│   ├── App.tsx                 # Main component
│   ├── main.tsx                # Entry point
│   └── index.css               # Global styles
├── package.json
└── README.md
```

## ✅ Pre-Deployment Checklist

- [ ] Updated contact information
- [ ] Replaced placeholder content
- [ ] Updated CNAME file with your domain
- [ ] Tested locally with `npm run dev`
- [ ] Built successfully with `npm run build`
- [ ] Updated package.json with correct homepage URL
- [ ] Committed all changes to Git

## 🆘 Troubleshooting

### Site shows 404 error
- Verify gh-pages branch exists
- Check homepage URL in package.json
- Wait 5-10 minutes after deployment
- Clear browser cache

### Custom domain not working
- Verify DNS records are correct
- Check CNAME file exists in public folder
- Wait for DNS propagation (up to 48 hours)
- Use https://www.whatsmydns.net/ to check

### Build errors
```bash
rm -rf node_modules
npm install
npm run build
```

## 📞 Support

For questions or issues:
- Check the [GitHub Pages documentation](https://pages.github.com/)
- Contact: tylermissinger@gmail.com

## 📄 License

This project is proprietary and confidential.
© 2024 DIVINE APEX LLC. All rights reserved.

---

**Built with ❤️ using React + Vite + Tailwind CSS**
