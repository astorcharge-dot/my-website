# 🌐 DNS Setup Guide for DIVINE APEX Website

## Where to Put DNS Codes

Your DNS records need to be added at your **domain registrar** - this is the company where you purchased your domain name.

---

## 📍 Step 1: Find Your Domain Registrar

Your domain registrar could be one of these popular services:
- **GoDaddy**
- **Namecheap**
- **Google Domains**
- **Cloudflare**
- **Hover**
- **Domain.com**
- **Network Solutions**

If you're not sure, you can check at: https://lookup.icann.org/

---

## 🔑 Step 2: Add DNS Records

### For GitHub Pages Hosting:

Log in to your domain registrar and navigate to DNS settings. Add these **5 records**:

```
╔═══════════════════════════════════════════════╗
║           DNS RECORDS TO ADD                  ║
╚═══════════════════════════════════════════════╝

Record 1
─────────────────────────────
Type:     A
Host/Name: @ (or blank or apex)
Value:    185.199.108.153
TTL:      3600

Record 2
─────────────────────────────
Type:     A
Host/Name: @ (or blank or apex)
Value:    185.199.109.153
TTL:      3600

Record 3
─────────────────────────────
Type:     A
Host/Name: @ (or blank or apex)
Value:    185.199.110.153
TTL:      3600

Record 4
─────────────────────────────
Type:     A
Host/Name: @ (or blank or apex)
Value:    185.199.111.153
TTL:      3600

Record 5 (for www subdomain)
─────────────────────────────
Type:     CNAME
Host/Name: www
Value:    YOUR_GITHUB_USERNAME.github.io
TTL:      3600
```

**Important:** Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username!

---

## 📚 Registrar-Specific Instructions

### GoDaddy

1. Login to **GoDaddy.com**
2. Go to **My Products**
3. Find your domain → Click **DNS**
4. Scroll to **Records** section
5. Click **Add** button for each record
6. Enter the values from above
7. Click **Save**

### Namecheap

1. Login to **Namecheap.com**
2. Go to **Domain List**
3. Click **Manage** next to your domain
4. Click **Advanced DNS** tab
5. Click **Add New Record**
6. Enter the values from above
7. Click the ✓ checkmark to save

### Google Domains

1. Login to **domains.google.com**
2. Click on your domain
3. Click **DNS** in the left menu
4. Scroll to **Custom resource records**
5. Add each record
6. Click **Add**

### Cloudflare

1. Login to **Cloudflare.com**
2. Select your domain
3. Click **DNS** icon
4. Click **Add record**
5. Enter the values from above
6. **Important:** Set Proxy status to **DNS only** (gray cloud icon)
7. Click **Save**

---

## ✅ Step 3: Verify DNS Settings

After adding DNS records:

1. **Wait 15-30 minutes** for propagation to start
2. **Check DNS status** at: https://www.whatsmydns.net/
   - Enter your domain name
   - Select "A" record type
   - Click Search
   - You should see the GitHub IP addresses

3. **Check from Terminal** (Mac/Linux):
   ```bash
   nslookup yourdomain.com
   ```
   Should show the GitHub IP addresses (185.199.108.153, etc.)

---

## 📋 Common Questions

### What does "@" mean in the Host/Name field?
- **@** = your root domain (e.g., divineapex.com)
- Some registrars use blank field instead of @
- Some use "apex" instead of @
- All three mean the same thing!

### What is TTL?
- **TTL** = Time To Live
- **3600** = 1 hour (recommended)
- Some registrars use "Auto" or "Default" - that's fine
- Lower TTL = faster updates, but more DNS queries

### Should I delete old DNS records?
- **Yes**, if you have existing **A records** or **CNAME records** pointing elsewhere
- You can't have multiple A records for @ - remove old ones
- Keep your MX records (for email) if you have them

### What about email?
- If you use email with your domain (e.g., you@divineapex.com)
- **DO NOT** delete MX, TXT, or SPF records
- Only replace A and CNAME records as shown above

---

## ⏱️ DNS Propagation Timeline

```
Immediately       → DNS records saved at registrar
15-30 minutes     → Propagation begins
1-2 hours         → Usually fully working
Up to 48 hours    → Maximum time (rare)
```

**Tip:** Use incognito/private browsing to test - regular browser caches DNS!

---

## 🔒 Step 4: Enable HTTPS

After DNS propagates (wait at least 1 hour):

1. Go to your GitHub repository
2. Click **Settings** → **Pages**
3. Check ✅ **Enforce HTTPS**
4. Wait 5-10 minutes for SSL certificate

Your site will now be secure with https://!

---

## 🎯 Complete Setup Checklist

- [ ] Identified where I bought my domain
- [ ] Logged in to domain registrar
- [ ] Found DNS management section
- [ ] Added all 4 A records with GitHub IPs
- [ ] Added CNAME record for www subdomain
- [ ] Used correct GitHub username in CNAME value
- [ ] Saved/published DNS changes
- [ ] Created CNAME file in public folder
- [ ] Deployed website to GitHub Pages
- [ ] Added custom domain in GitHub Pages settings
- [ ] Waited for DNS propagation
- [ ] Enabled HTTPS in GitHub Pages
- [ ] Tested website at custom domain

---

## 🆘 Troubleshooting

### Problem: Site not loading after 48 hours
**Solution:**
- Verify all 4 A records are correct
- Check no typos in IP addresses
- Confirm CNAME file exists in public folder
- Make sure GitHub Pages is enabled

### Problem: "DNS_PROBE_FINISHED_NXDOMAIN" error
**Solution:**
- DNS records not yet propagated - wait longer
- Check DNS records are correct at registrar
- Clear your DNS cache:
  - **Mac:** `sudo dscacheutil -flushcache`
  - **Windows:** `ipconfig /flushdns`

### Problem: Site shows "404 - Page not found"
**Solution:**
- CNAME file is missing or incorrect
- GitHub Pages not enabled on gh-pages branch
- Custom domain not set in GitHub Pages settings
- Redeploy: `npm run deploy`

### Problem: "Not Secure" or HTTPS errors
**Solution:**
- Wait for DNS to fully propagate first
- Then enable "Enforce HTTPS" in GitHub settings
- SSL certificate can take 24 hours to provision
- Try again later

### Problem: Email stopped working
**Solution:**
- You may have deleted email (MX) records
- Go back to DNS and re-add your email provider's MX records
- Contact your email provider for correct MX record values

---

## 📞 Need More Help?

### DNS Checker Tools:
- https://www.whatsmydns.net/
- https://dnschecker.org/
- https://mxtoolbox.com/SuperTool.aspx

### GitHub Pages Documentation:
- https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

### Contact Domain Registrar:
- Most registrars have 24/7 chat support
- They can help you add DNS records
- Have this guide ready to show them what you need

### Contact Developer:
- Email: tylermissinger@gmail.com
- Include: domain name, registrar name, and error screenshots

---

## 📊 Example: Complete DNS Setup

**Example scenario:**
- Domain: `divineapex.com`
- GitHub username: `johndoe`
- Registrar: Namecheap

**DNS Records:**
```
A      @      185.199.108.153      3600
A      @      185.199.109.153      3600
A      @      185.199.110.153      3600
A      @      185.199.111.153      3600
CNAME  www    johndoe.github.io    3600
```

**GitHub Settings:**
- Repository: `johndoe/divine-apex-website`
- Custom domain: `divineapex.com`
- Enforce HTTPS: ✅ (enabled after DNS propagates)

**Result:**
- ✅ http://divineapex.com → redirects to https://divineapex.com
- ✅ http://www.divineapex.com → redirects to https://divineapex.com
- ✅ https://divineapex.com → shows your website
- ✅ https://www.divineapex.com → shows your website

---

## 🎉 Success!

Once everything is set up, your professional website will be:
- ✅ Live at your custom domain
- ✅ Secure with HTTPS
- ✅ Fast and responsive
- ✅ Easy to update

**Congratulations on your new website! 🚀**

---

*Last updated: 2024*
*© DIVINE APEX LLC*
