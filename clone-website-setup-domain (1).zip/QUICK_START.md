# ⚡ Quick Start Guide - DIVINE APEX Website

## Get Your Website Live in 10 Minutes!

Follow these simple steps to deploy your website.

---

## 🎯 Step 1: Upload to GitHub (2 minutes)

1. **Create a GitHub account** at https://github.com if you don't have one

2. **Create a new repository:**
   - Click the **+** button (top right) → **New repository**
   - Name: `divine-apex-website`
   - Make it **Public**
   - Click **Create repository**

3. **Upload your code:**

Open Terminal (Mac) or Command Prompt (Windows) in your project folder and run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/divine-apex-website.git
git push -u origin main
```

**Replace `YOUR_USERNAME` with your actual GitHub username!**

---

## 📦 Step 2: Install Deployment Tool (1 minute)

In your Terminal/Command Prompt, run:

```bash
npm install --save-dev gh-pages
```

---

## ⚙️ Step 3: Configure for Deployment (2 minutes)

1. **Open `package.json`**

2. **Add this line** after `"name"` or `"version"`:
```json
"homepage": "https://YOUR_USERNAME.github.io/divine-apex-website",
```

3. **Add these lines** inside the `"scripts"` section:
```json
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"
```

**Remember to replace `YOUR_USERNAME` with your GitHub username!**

**Example of what it should look like:**
```json
{
  "name": "react-vite-tailwind",
  "homepage": "https://johndoe.github.io/divine-apex-website",
  "version": "0.0.0",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

---

## 🚀 Step 4: Deploy! (1 minute)

Run this command:

```bash
npm run deploy
```

Wait 30-60 seconds. You'll see "Published" when it's done!

---

## ⚙️ Step 5: Enable GitHub Pages (1 minute)

1. Go to your repository on GitHub: `https://github.com/YOUR_USERNAME/divine-apex-website`
2. Click **Settings** (top right)
3. Click **Pages** (left sidebar)
4. Under "Source", select **gh-pages** branch
5. Click **Save**

**Your website is now live!** 🎉

Visit: `https://YOUR_USERNAME.github.io/divine-apex-website`

---

## 🌐 Step 6: Add Custom Domain (Optional - 5 minutes)

If you have a custom domain (like `divineapex.com`):

### A. Update CNAME file
1. Open `public/CNAME`
2. Replace `divineapex.com` with your actual domain
3. Save the file

### B. Add DNS Records

Go to your domain registrar (where you bought your domain) and add these DNS records:

```
Type: A      Name: @      Value: 185.199.108.153
Type: A      Name: @      Value: 185.199.109.153
Type: A      Name: @      Value: 185.199.110.153
Type: A      Name: @      Value: 185.199.111.153
Type: CNAME  Name: www    Value: YOUR_USERNAME.github.io
```

**See `DNS_SETUP_GUIDE.md` for detailed instructions!**

### C. Configure in GitHub

1. Go to GitHub Settings → Pages
2. Under "Custom domain", enter your domain: `divineapex.com`
3. Click **Save**
4. Wait 30-60 minutes for DNS to propagate
5. Check ✅ **Enforce HTTPS**

---

## 🔄 How to Update Your Website

After making changes to your code:

```bash
git add .
git commit -m "Updated website"
git push
npm run deploy
```

Your changes will be live in 1-2 minutes!

---

## ✅ Checklist

- [ ] Created GitHub account
- [ ] Created new repository on GitHub
- [ ] Pushed code to GitHub
- [ ] Installed gh-pages package
- [ ] Updated package.json with homepage
- [ ] Added deploy scripts to package.json
- [ ] Ran `npm run deploy`
- [ ] Enabled GitHub Pages (selected gh-pages branch)
- [ ] Website is live!
- [ ] (Optional) Added custom domain
- [ ] (Optional) Configured DNS records
- [ ] (Optional) Enabled HTTPS

---

## 🆘 Common Issues

### "Repository not found" error
**Solution:** Make sure you created the repository on GitHub first and used the correct URL

### "Permission denied" error
**Solution:** You may need to authenticate with GitHub. Run:
```bash
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

### Site shows 404 error
**Solution:** 
- Make sure you selected `gh-pages` branch in Settings → Pages
- Wait 5-10 minutes
- Clear your browser cache
- Try in incognito/private mode

### Deploy command not found
**Solution:** 
- Make sure you ran `npm install --save-dev gh-pages`
- Check that deploy scripts are in package.json
- Try: `npm install` then `npm run deploy`

---

## 📞 Need Help?

1. **Check the detailed guides:**
   - `README.md` - Full documentation
   - `DNS_SETUP_GUIDE.md` - DNS configuration help

2. **Contact:**
   - Email: tylermissinger@gmail.com

3. **Resources:**
   - GitHub Pages Docs: https://pages.github.com/
   - GitHub Help: https://docs.github.com/

---

## 🎉 Success!

Your professional business website is now live! Share it with the world:

- ✅ Modern, responsive design
- ✅ Fast loading speeds
- ✅ Professional appearance
- ✅ Easy to update
- ✅ Secure HTTPS

**Welcome to the web! 🚀**

---

*© 2024 DIVINE APEX LLC - Built with React + Vite + Tailwind CSS*
